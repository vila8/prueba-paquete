# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['email_sender']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp>=3.8.1,<4.0.0',
 'asyncio>=3.4.3,<4.0.0',
 'requests>=2.27.1,<3.0.0',
 'sentry-sdk>=1.5.12,<2.0.0']

setup_kwargs = {
    'name': 'email-sender',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Jesús Vila',
    'author_email': '22890621+vila8@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
